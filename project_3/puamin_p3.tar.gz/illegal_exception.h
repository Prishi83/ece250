// Used for try-catch block for INSERT, CLASSIFY, ERASE commands

#ifndef ILLEGAL_EXCEPTION_H
#define ILLEGAL_EXCEPTION_H

class illegal_exception {
public:
    illegal_exception() {}  // constructor
};

#endif